package com.zte.sputnik.parse;

public interface TestSubjectSelector {
    boolean selectTestSubject(Class clazz);
}
